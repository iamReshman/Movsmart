import json
import time
import platform

# Try to import GPIO
try:
    import RPi.GPIO as GPIO
except ImportError:
    # Mock GPIO for Windows or non-Pi environments
    class MockGPIO:
        BCM = 'BCM'
        IN = 'IN'
        def setmode(self, *args): pass
        def setup(self, *args): pass
        def input(self, pin): return False  # Default to "Vacant"
        def cleanup(self): pass
    GPIO = MockGPIO()

# Try to import serial
try:
    import serial
except ImportError:
    # Mock serial for GPS testing
    class MockSerial:
        def __init__(self, *args, **kwargs): pass
        def readline(self):
            # Simulated NMEA sentence
            return b"$GPGGA,123519,4807.038,N,01131.000,E,1,08,0.9,545.4,M,46.9,M,,*47"
        def close(self): pass
    serial = type('serial', (), {'Serial': MockSerial})

import pynmea2

# File to write data to (platform-safe)
import os
DATA_FILE = os.path.join(os.path.expanduser("~"), "bus_data.json")

SEAT_PINS = [17, 27, 22]

# Setup GPIO
GPIO.setmode(GPIO.BCM)
for pin in SEAT_PINS:
    GPIO.setup(pin, GPIO.IN)

import random

def get_seat_status():
    return [random.choice([True, False]) for _ in SEAT_PINS]


# Simulated GPS path
simulated_coords = [
    (12.9716, 77.5946),
    (12.9720, 77.5950),
    (12.9725, 77.5955),
    (12.9730, 77.5960),
    (12.9735, 77.5965)
]
coord_index = 0

def get_gps_location():
    global coord_index
    try:
        if platform.system() != "Windows":
            port = serial.Serial('/dev/serial0', baudrate=9600, timeout=1)
            while True:
                data = port.readline().decode('ascii', errors='replace')
                if data.startswith('$GPGGA') or data.startswith('$GPRMC'):
                    msg = pynmea2.parse(data)
                    if hasattr(msg, 'latitude') and hasattr(msg, 'longitude'):
                        return msg.latitude, msg.longitude
        else:
            # Simulate changing GPS on Windows
            lat, lon = simulated_coords[coord_index % len(simulated_coords)]
            coord_index += 1
            return lat, lon
    except Exception as e:
        print("GPS Error:", e)
        return 12.9716, 77.5946


def main():
    while True:
        seats = get_seat_status()
        lat, lon = get_gps_location()
        if lat and lon:
            with open(DATA_FILE, 'w') as f:
                json.dump({"latitude": lat, "longitude": lon, "seats": seats}, f)
        print("Updated:", lat, lon, seats)
        time.sleep(5)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        GPIO.cleanup()
