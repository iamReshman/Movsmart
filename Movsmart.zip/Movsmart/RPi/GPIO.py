# RPi/GPIO.py

BCM = BOARD = IN = OUT = LOW = HIGH = None

def setmode(mode): print(f"[Mock GPIO] setmode({mode})")
def setup(pin, mode): print(f"[Mock GPIO] setup(pin={pin}, mode={mode})")
def output(pin, value): print(f"[Mock GPIO] output(pin={pin}, value={value})")
def input(pin): return False
def cleanup(): print(f"[Mock GPIO] cleanup()")
